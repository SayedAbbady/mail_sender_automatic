<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Eaalim</title>

  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
  <style>
  
    .wipper {
      position: relative;
      width: 450px;
      height: 1224px;
      margin: auto;
      
      /* filter: brightness(0.4) blur(2px); */
    }
    
    /*
    @media (max-width: 450px) {
      .wipper {
        width: 100%;
      }
    }
    */
    .conent {
      background-image: url('https://eaalim.com/sayed_Dont_delete/masjid-pogung-dalangan-kUzYKihcK9I-unsplash.png');
      /* position:absolute; */
      width: 100%;
      height: 100%;
      z-index: 10;
      background-size: cover;
  background-position: 66%;
    }

    .conent header {
      text-align: right;
    }

    .conent header img {
      width: 60px;
      margin: 7px;
    }

    .conent .learnQuran {
      /* float: right; */
      /* width:  ; */
      width: 50%;
      margin-left: auto;
    }

    .conent .learnQuran p.s1 {
      text-transform: uppercase;
      color: #fff;
      font-weight: bold;
      margin-bottom: 0;
      font-size: 12px;

    }

    .conent .learnQuran p.s2 {
      margin-top: 0;
      color: #FFC562;
      font-size: 12px;
      line-height: 20px;
    }

    .conent .onlineQuran {
      text-transform: uppercase;
      position: relative;
      font-family: system-ui;
      color: #fff;
    }

    .conent .onlineQuran span.s1 {
      /* position: absolute; */
      font-size: 18px;
      left: -115px;
      top: -83px;
    }

    .conent .onlineQuran span.s2 {
      font-weight: 700;
      font-size: 51px;
      margin: 0;
      font-family: system-ui;
      margin-top: -200px;
      display: inline-block;
      margin-left: -175px;
      margin-bottom: 0;
    }

    .conent .onlineQuran span.s2 span {
      color: #FFC562;
      font-size: 234px;
      z-index: 10;
      /* margin-top: -149px; */
      font-weight: bold;

    }

    .conent .onlineQuran span.s3 {
      display: block;
      margin-top: -48px;
      text-align: right;
      font-size: 20px;
      margin-right: 78px;
    }

    .img-offer {
      padding: 15px;
      margin-top: -100px;
      z-index: 15;
      position: relative;
    }

    .mr {
      margin-bottom: -7px;
    }

    .img-offer .img {
      width: 150px;
    }

    .img-offer .offer-image {
      width: 115px;
    }

    .img-offer .offer-image-last {
      width: 280px;
      margin-left: 20px;
      border-radius: 7px;

    }

    .text-div>span {
      color: #FFC562;
      font-family: system-ui;
      padding: 15px;
      display: block;
    }

    .text-div .adults {
      font-family: system-ui;
      display: block;
      color: #B2DBE8;
      font-size: 18px;
    }

    .links-services {
      height: auto;
    }

    .links-services a {
      width: 80%;
      margin: 0 auto;
      display: block;
    }

    .contact {
      padding: 15px;
      margin-top: -20px;
      margin-left: 20px;
      color: #fff;
      font-family: system-ui;
      font-size: 10px;
    }

    .contact img {
      width: 50px;
      /* display: inline-block; */
    }

    .soical-media {
      background: #fff;
      padding: 24px;
      margin: auto;
      margin-top: -11px;
      width: 87%;
      border-radius: 5px;
      text-align: center;

    }

    .soical-media a {
      text-decoration: none;
    }

    .soical-media i {
      display: inline-block;
      
      margin-right: 32px;
    }
  </style>
</head>

<body>
  <div class="wipper">
    <div class="container-wid"></div>
    <div class="conent">
      
      <div>
        <img width="110%" src="https://eaalim.com/sayed_Dont_delete/group19.png" alt="">
      </div>
      
      <div class="links-services">
        <a href="https://eaalim.com/syllabus" target="_blank">
          <img width="100%" src="https://eaalim.com/sayed_Dont_delete/group3.png" alt="">
        </a>
        <a href="https://eaalim.com/eaalim-games/" target="_blank">
          <img width="100%" src="https://eaalim.com/sayed_Dont_delete/group9.png" alt="">
        </a>
        <table class="contact">
          <tr>
            <td>
              <img src="https://eaalim.com/sayed_Dont_delete/011424254.png" alt="">
            </td>
            <td>
              <span>+442081233611</span>
            </td>

            <td>
              <img src="https://eaalim.com/sayed_Dont_delete/bg434354.png" alt="">
            </td>
            <td>
              <span>+201148362722</span>
            </td>
          </tr>





        </table>
      </div>
      <footer class="soical-media">
        <a href="https://www.facebook.com/Eaaliminstitute/">
          <img src="https://eaalim.com/sayed_Dont_delete/fb.png" alt="">
        </a>
        <a href="https://youtube.com/c/EaalimInstitutelearnQuranonline">
          <img src="https://eaalim.com/sayed_Dont_delete/you.png" alt="">
        </a>
        <a href="https://eaalim.com">
          <img src="https://eaalim.com/sayed_Dont_delete/web.png" alt="">
        </a>
        <a href="https://www.linkedin.com/company/eaalim-institute">
          <img src="https://eaalim.com/sayed_Dont_delete/lin.png" alt="">
        </a>
      </footer>
    </div>
  </div>
</body>

</html><?php /**PATH E:\My Clients\Eaalim\sendMessage\files\resources\views/test.blade.php ENDPATH**/ ?>